# Audamus Skyline

Premium residential website for **Audamus Skyline** — Area More, Fulbagan, Pandaveswar (adjacent to NH-14 / Old NH-60), West Bengal.

Built with Next.js 15 (App Router), React 19, TypeScript, Tailwind CSS v4, Framer Motion, React Hook Form + Zod, and self-hosted fonts (Playfair Display, Poppins, Inter) via `@fontsource`.

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Build for production

```bash
npm run build
npm run start
```

## Project structure

```
src/
  app/
    page.tsx              → homepage (assembles all sections)
    layout.tsx             → root layout, fonts, SEO metadata, JSON-LD
    privacy-policy/page.tsx
    terms/page.tsx
    robots.ts               → /robots.txt
    sitemap.ts               → /sitemap.xml
    globals.css              → design tokens (colors, fonts, utility classes)
  components/               → Navbar, Hero, About, Amenities, MasterPlan,
                               FloorPlans, Specifications, Location, Gallery,
                               ConstructionUpdate, Contact, Footer,
                               WhatsAppButton, StickyBookVisit, PageLoader,
                               SectionHeading, SkylineMotif
  lib/data.ts                → all editable content (copy, amenities, specs,
                                floor plans, location distances, gallery labels)
```

Almost all editable content lives in `src/lib/data.ts` — update phone, email,
address, amenities, specifications, floor plan dimensions, and location
distances there without touching component code.

## Things to finish before launch

1. **Real photography/renders** — the Gallery section currently uses styled
   placeholder tiles. Replace `GALLERY_ITEMS` in `src/lib/data.ts` and swap
   the placeholder tiles in `src/components/Gallery.tsx` for `next/image`
   with your actual apartment, clubhouse, and amenity photos.
2. **Brochure & floor plan PDFs** — the "Download Brochure" and "Download
   PDF" buttons are UI-only. Add real PDF files to `/public` and point the
   `href` at them, or wire up a download handler.
3. **Contact form backend** — `src/components/Contact.tsx` currently
   simulates a submission. Connect it to an API route, email service (e.g.
   Resend), or CRM webhook inside the `onSubmit` handler.
4. **Company details** — confirm phone, email, and address in
   `src/lib/data.ts` (`COMPANY` object) and in `src/app/layout.tsx`
   (JSON-LD `address` block).
5. **Domain** — replace `https://www.audamusskyline.in` in
   `src/app/layout.tsx`, `src/app/robots.ts`, and `src/app/sitemap.ts` with
   your actual production domain once finalized.

## Deploying to Vercel

1. Push this project to a GitHub/GitLab/Bitbucket repository.
2. Go to vercel.com/new and import the repository.
3. Framework preset: **Next.js** (auto-detected). No environment variables
   are required for the current feature set.
4. Click **Deploy**. Vercel will build and host the site automatically on
   every push to your main branch.

Alternatively, from the project root:

```bash
npm i -g vercel
vercel
```

and follow the prompts.

## Notes on design

- Colors, type, and component styling follow the emerald (#0F5D4B) / gold
  (#D4AF37) / white / dark (#111111) palette and Playfair Display / Poppins /
  Inter type system.
- The abstract skyline silhouette (`src/components/SkylineMotif.tsx`) is an
  original vector motif reused across the hero background and footer to tie
  the visual language to the project name.
- The Master Plan and Location "connectivity compass" are original SVG
  illustrations built from your project's own distance data — not copied
  from any third-party site.
