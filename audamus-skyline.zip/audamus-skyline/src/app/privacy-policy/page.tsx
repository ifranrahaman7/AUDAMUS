import type { Metadata } from "next";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { COMPANY } from "@/lib/data";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `Privacy Policy for ${COMPANY.project} by ${COMPANY.name}.`,
};

export default function PrivacyPolicyPage() {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-3xl px-6 pb-24 pt-40 lg:px-10">
        <p className="section-eyebrow mb-4">Legal</p>
        <h1 className="font-display text-4xl font-semibold text-dark">Privacy Policy</h1>
        <p className="mt-3 font-body text-sm text-dark/50">Last updated: July 2026</p>

        <div className="mt-10 space-y-8 font-body text-[0.95rem] leading-relaxed text-dark/75">
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">1. Information We Collect</h2>
            <p className="mt-3">
              When you enquire about {COMPANY.project} through our website, contact form, or by phone,
              we may collect your name, phone number, email address, and any details you choose to
              share about your requirements.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">2. How We Use Your Information</h2>
            <p className="mt-3">
              Information you provide is used solely to respond to your enquiry, schedule site visits,
              share brochures and pricing, and provide project updates you have requested. We do not
              sell your personal information to third parties.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">3. Cookies</h2>
            <p className="mt-3">
              Our website may use basic cookies to improve browsing experience and understand general
              usage patterns. You can disable cookies in your browser settings at any time.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">4. Data Sharing</h2>
            <p className="mt-3">
              We do not share your personal details with unrelated third parties. Information may be
              shared internally within {COMPANY.name}&apos;s sales and marketing team to assist with your
              enquiry.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">5. Your Rights</h2>
            <p className="mt-3">
              You may request access to, correction of, or deletion of your personal information at
              any time by writing to {COMPANY.email}.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">6. Contact Us</h2>
            <p className="mt-3">
              For any privacy-related questions, please reach out at {COMPANY.email} or {COMPANY.phone}.
            </p>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
