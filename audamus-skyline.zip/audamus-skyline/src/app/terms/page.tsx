import type { Metadata } from "next";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { COMPANY } from "@/lib/data";

export const metadata: Metadata = {
  title: "Terms & Conditions",
  description: `Terms & Conditions for ${COMPANY.project} by ${COMPANY.name}.`,
};

export default function TermsPage() {
  return (
    <>
      <Navbar />
      <main className="mx-auto max-w-3xl px-6 pb-24 pt-40 lg:px-10">
        <p className="section-eyebrow mb-4">Legal</p>
        <h1 className="font-display text-4xl font-semibold text-dark">Terms &amp; Conditions</h1>
        <p className="mt-3 font-body text-sm text-dark/50">Last updated: July 2026</p>

        <div className="mt-10 space-y-8 font-body text-[0.95rem] leading-relaxed text-dark/75">
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">1. General</h2>
            <p className="mt-3">
              This website is published by {COMPANY.name} for the purpose of providing information
              about {COMPANY.project}, located at {COMPANY.address}. By using this website, you agree
              to the terms outlined below.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">2. Indicative Information</h2>
            <p className="mt-3">
              Renders, floor plans, master plan layouts, amenities, specifications, and distances shown
              on this website are indicative and for representation purposes only. They are subject to
              change based on final approvals from competent authorities and are not to be construed as
              a legal offering.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">3. No Booking Guarantee</h2>
            <p className="mt-3">
              Submission of an enquiry through this website does not constitute a booking or
              reservation. Bookings are confirmed only through official sale documentation executed
              with {COMPANY.name}.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">4. Pricing</h2>
            <p className="mt-3">
              Prices, if displayed elsewhere, are subject to change without prior notice and do not
              include applicable taxes, statutory charges, or registration costs unless stated otherwise.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">5. Intellectual Property</h2>
            <p className="mt-3">
              All content on this website, including text, graphics, and design, is the property of
              {" "}{COMPANY.name} and may not be reproduced without written consent.
            </p>
          </section>
          <section>
            <h2 className="font-heading text-lg font-semibold text-dark">6. Contact</h2>
            <p className="mt-3">
              For questions regarding these terms, contact us at {COMPANY.email} or {COMPANY.phone}.
            </p>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
