import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Amenities from "@/components/Amenities";
import MasterPlan from "@/components/MasterPlan";
import FloorPlans from "@/components/FloorPlans";
import Specifications from "@/components/Specifications";
import Location from "@/components/Location";
import Gallery from "@/components/Gallery";
import ConstructionUpdate from "@/components/ConstructionUpdate";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import PageLoader from "@/components/PageLoader";

export default function Home() {
  return (
    <>
      <PageLoader />
      <Navbar />
      <main className="pb-20 lg:pb-0">
        <Hero />
        <About />
        <Amenities />
        <MasterPlan />
        <FloorPlans />
        <Specifications />
        <Location />
        <Gallery />
        <ConstructionUpdate />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
