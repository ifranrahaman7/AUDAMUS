import type { MetadataRoute } from "next";

const base = "https://www.audamusskyline.in";

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: `${base}/`, lastModified: new Date(), priority: 1 },
    { url: `${base}/privacy-policy`, lastModified: new Date(), priority: 0.3 },
    { url: `${base}/terms`, lastModified: new Date(), priority: 0.3 },
  ];
}
