import type { Metadata } from "next";
import "@fontsource/playfair-display/500.css";
import "@fontsource/playfair-display/600.css";
import "@fontsource/playfair-display/700.css";
import "@fontsource/playfair-display/800.css";
import "@fontsource/playfair-display/900.css";
import "@fontsource/playfair-display/700-italic.css";
import "@fontsource/poppins/300.css";
import "@fontsource/poppins/400.css";
import "@fontsource/poppins/500.css";
import "@fontsource/poppins/600.css";
import "@fontsource/poppins/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "./globals.css";
import WhatsAppButton from "@/components/WhatsAppButton";
import StickyBookVisit from "@/components/StickyBookVisit";
import { COMPANY } from "@/lib/data";

const siteUrl = "https://www.audamusskyline.in";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "Audamus Skyline | Premium Apartments in Fulbagan, Pandaveswar",
    template: "%s | Audamus Skyline",
  },
  description:
    "Audamus Skyline is a premium residential community at Area More, Fulbagan, Pandaveswar — adjacent to NH-14 (Old NH-60). 2 & 3 BHK apartments with resort-style amenities and excellent connectivity.",
  keywords: [
    "Audamus Skyline",
    "Audamus Fulbagan Heights",
    "flats in Pandaveswar",
    "apartments in Fulbagan",
    "NH-14 residential project West Bengal",
    "premium apartments Pandaveswar",
    "2 BHK 3 BHK Pandaveswar",
  ],
  authors: [{ name: "Audamus" }],
  openGraph: {
    title: "Audamus Skyline | Premium Living. Perfectly Connected.",
    description:
      "A premium residential community at Area More, Fulbagan, Pandaveswar, adjacent to NH-14 (Old NH-60). Discover 2 & 3 BHK homes with resort-style amenities.",
    url: siteUrl,
    siteName: "Audamus Skyline",
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Audamus Skyline | Premium Living. Perfectly Connected.",
    description:
      "A premium residential community at Area More, Fulbagan, Pandaveswar, adjacent to NH-14 (Old NH-60).",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ApartmentComplex",
    name: COMPANY.project,
    brand: COMPANY.name,
    description:
      "Audamus Skyline is a premium residential community at Area More, Fulbagan, Pandaveswar, adjacent to NH-14 (Old NH-60), West Bengal.",
    address: {
      "@type": "PostalAddress",
      streetAddress: "Area More, Fulbagan",
      addressLocality: "Pandaveswar",
      addressRegion: "West Bengal",
      addressCountry: "IN",
    },
    telephone: COMPANY.phone,
    email: COMPANY.email,
    url: siteUrl,
  };

  return (
    <html lang="en">
      <body className="antialiased">
        {children}
        <WhatsAppButton />
        <StickyBookVisit />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </body>
    </html>
  );
}
