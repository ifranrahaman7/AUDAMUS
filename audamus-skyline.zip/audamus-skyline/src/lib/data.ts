// Central content source for Audamus Skyline
// Keeping all copy/data here makes the site easy to update without touching components.

export const COMPANY = {
  name: "Audamus",
  project: "Audamus Skyline",
  tagline: "Premium Living. Perfectly Connected.",
  phone: "+91 74390 88367",
  phoneRaw: "917439088367",
  email: "founder.audamus@gmail.com",
  address: "Area More, Fulbagan, Pandaveswar, West Bengal",
  highway: "Adjacent to NH-14 (Old NH-60)",
};

export const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Amenities", href: "#amenities" },
  { label: "Master Plan", href: "#master-plan" },
  { label: "Floor Plans", href: "#floor-plans" },
  { label: "Specifications", href: "#specifications" },
  { label: "Location", href: "#location" },
  { label: "Gallery", href: "#gallery" },
  { label: "Progress", href: "#construction" },
  { label: "Contact", href: "#contact" },
];

export const HIGHLIGHTS = [
  "Premium Apartments",
  "Landscaped Gardens",
  "Swimming Pool",
  "Clubhouse",
  "Gymnasium",
  "Children's Play Area",
  "Jogging Track",
  "Senior Citizen Zone",
  "Community Hall",
  "Indoor Games",
  "24×7 Security",
  "CCTV Surveillance",
  "Power Backup",
  "Visitor Parking",
  "Rainwater Harvesting",
  "Fire Safety Systems",
  "High-Speed Elevators",
];

export type Amenity = { name: string; icon: string; blurb: string };

export const AMENITIES: Amenity[] = [
  { name: "Swimming Pool", icon: "pool", blurb: "A resort-style pool for morning laps and evening unwinding." },
  { name: "Gymnasium", icon: "gym", blurb: "Modern equipment for strength and cardio training." },
  { name: "Yoga Deck", icon: "yoga", blurb: "An open-air deck for yoga and mindful mornings." },
  { name: "Clubhouse", icon: "clubhouse", blurb: "A social hub for gatherings, celebrations and downtime." },
  { name: "Kids' Play Area", icon: "kids", blurb: "Safe, shaded play equipment for younger residents." },
  { name: "Indoor Games", icon: "games", blurb: "Table tennis, carrom and board games under one roof." },
  { name: "Community Hall", icon: "hall", blurb: "A versatile space for festivals, functions and meetings." },
  { name: "Jogging Track", icon: "track", blurb: "A dedicated landscaped loop for walking and running." },
  { name: "Landscaped Gardens", icon: "garden", blurb: "Curated green pockets that soften every walk home." },
  { name: "Senior Citizen Park", icon: "senior", blurb: "A calm, shaded corner designed for elder residents." },
  { name: "Visitor Parking", icon: "parking", blurb: "Dedicated bays so guests never have to circle the block." },
  { name: "Power Backup", icon: "power", blurb: "Uninterrupted backup for common areas and lifts." },
  { name: "24×7 Security", icon: "security", blurb: "Round-the-clock trained personnel at every access point." },
  { name: "CCTV Surveillance", icon: "cctv", blurb: "Monitored coverage across entrances and common areas." },
  { name: "Rainwater Harvesting", icon: "rain", blurb: "A sustainable system that replenishes local groundwater." },
];

export type SpecGroup = { title: string; items: { label: string; value: string }[] };

export const SPECIFICATIONS: SpecGroup[] = [
  {
    title: "Structure",
    items: [{ label: "Frame", value: "Earthquake-resistant RCC frame structure" }],
  },
  {
    title: "Flooring",
    items: [{ label: "Living & Bedrooms", value: "Premium vitrified tiles" }],
  },
  {
    title: "Kitchen",
    items: [
      { label: "Countertop", value: "Granite countertop" },
      { label: "Walls", value: "Designer ceramic wall tiles up to lintel level" },
      { label: "Sink", value: "Stainless steel sink with drainboard" },
    ],
  },
  {
    title: "Bathrooms",
    items: [
      { label: "Flooring", value: "Anti-skid ceramic flooring" },
      { label: "Fittings", value: "Premium sanitary ware and CP fittings" },
    ],
  },
  {
    title: "Doors & Windows",
    items: [
      { label: "Doors", value: "Flush doors with laminate finish" },
      { label: "Windows", value: "Powder-coated aluminium sliding windows" },
    ],
  },
  {
    title: "Electrical",
    items: [
      { label: "Wiring", value: "Concealed fire-retardant copper wiring" },
      { label: "Switches", value: "Modular switches and adequate power points" },
    ],
  },
  {
    title: "Security & Safety",
    items: [
      { label: "Entry", value: "Video door phone at every unit" },
      { label: "Fire Safety", value: "Fire detection and firefighting systems as per norms" },
    ],
  },
];

export type FloorPlan = {
  id: string;
  type: string;
  area: string;
  dimensions: { room: string; size: string }[];
};

export const FLOOR_PLANS: FloorPlan[] = [
  {
    id: "2bhk",
    type: "2 BHK",
    area: "890 – 1,050 sq.ft.",
    dimensions: [
      { room: "Living / Dining", size: "16'0\" x 12'6\"" },
      { room: "Master Bedroom", size: "12'0\" x 11'0\"" },
      { room: "Bedroom 2", size: "11'0\" x 10'0\"" },
      { room: "Kitchen", size: "10'0\" x 8'0\"" },
      { room: "Balcony", size: "9'0\" x 4'6\"" },
    ],
  },
  {
    id: "3bhk",
    type: "3 BHK",
    area: "1,240 – 1,480 sq.ft.",
    dimensions: [
      { room: "Living / Dining", size: "18'6\" x 13'0\"" },
      { room: "Master Bedroom", size: "13'0\" x 11'6\"" },
      { room: "Bedroom 2", size: "11'6\" x 10'6\"" },
      { room: "Bedroom 3", size: "10'6\" x 10'0\"" },
      { room: "Kitchen", size: "10'6\" x 8'6\"" },
      { room: "Balcony", size: "12'0\" x 4'6\"" },
    ],
  },
];

export type LocationEntry = { name: string; distance: string; note?: string; hours?: string };

export const LOCATION_DATA: Record<"healthcare" | "transport" | "leisure", LocationEntry[]> = {
  healthcare: [
    { name: "VijaySudha Healthcare", distance: "0.3 – 0.5 km", note: "Multi-speciality private hospital", hours: "24×7" },
    { name: "Pandaveswar PHC", distance: "~1.5 km", note: "Government Primary Health Centre", hours: "24×7" },
    { name: "LM Hospital", distance: "~2 km", note: "General hospital" },
    { name: "Panth Nagar Regional ECL Hospital", distance: "~4 km", note: "Regional hospital (ECL)" },
    { name: "Durgapur", distance: "25 – 30 km", note: "Multi-speciality & advanced care hubs" },
    { name: "Asansol", distance: "~30 km", note: "Multi-speciality & advanced care hubs" },
  ],
  transport: [
    { name: "NH-14 (Old NH-60)", distance: "Adjacent", note: "Direct highway access" },
    { name: "Pandaveswar Railway Station", distance: "2 – 2.5 km", note: "Andal–Sainthia branch line" },
    { name: "Andal Junction", distance: "10 – 12 km", note: "Major railway junction" },
    { name: "Pandaveswar Bus Stand", distance: "1 – 1.5 km", note: "Regular local & intercity buses" },
    { name: "Flyover More Bus Stop", distance: "~1 km" },
    { name: "Kazi Nazrul Islam Airport", distance: "15 – 18 km", note: "≈20–30 min drive" },
  ],
  leisure: [
    { name: "Children's Park, Pandaveswar", distance: "~2 km" },
    { name: "Maa Ghaghar Buri Temple", distance: "4 – 5 km" },
    { name: "Ajay River", distance: "5 – 7 km", note: "Riverside & picnic spot" },
    { name: "Ukhra Market", distance: "~5 km", note: "Everyday shopping" },
    { name: "Raniganj Market", distance: "~15 km" },
    { name: "Junction Mall, Durgapur", distance: "24 – 26 km" },
    { name: "City Centre, Durgapur", distance: "~25 km" },
    { name: "Maithon Dam", distance: "55 – 60 km", note: "Weekend getaway" },
  ],
};

export const CONSTRUCTION_PHASES = [
  { phase: "Foundation", progress: 100 },
  { phase: "Structure", progress: 80 },
  { phase: "Brickwork", progress: 55 },
  { phase: "Finishing", progress: 20 },
  { phase: "Possession", progress: 0, note: "Timeline shared on request" },
];

export const GALLERY_ITEMS = [
  { label: "Apartment Exterior", tone: "from-[#0F5D4B] to-[#123f34]" },
  { label: "Living Room", tone: "from-[#123f34] to-[#0a2a22]" },
  { label: "Bedroom", tone: "from-[#0F5D4B] to-[#0a2a22]" },
  { label: "Kitchen", tone: "from-[#16493c] to-[#0F5D4B]" },
  { label: "Clubhouse", tone: "from-[#0a2a22] to-[#0F5D4B]" },
  { label: "Swimming Pool", tone: "from-[#0F5D4B] to-[#1a5b4c]" },
  { label: "Gymnasium", tone: "from-[#123f34] to-[#0F5D4B]" },
  { label: "Landscaped Garden", tone: "from-[#0a2a22] to-[#16493c]" },
  { label: "Children's Play Area", tone: "from-[#0F5D4B] to-[#0a2a22]" },
  { label: "Community Hall", tone: "from-[#16493c] to-[#0a2a22]" },
];
