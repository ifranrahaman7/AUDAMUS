"use client";

import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";
import { HIGHLIGHTS, COMPANY } from "@/lib/data";

const STATS = [
  { value: "2–3", label: "BHK Residences" },
  { value: "17+", label: "Curated Amenities" },
  { value: "0 km", label: "From NH-14" },
  { value: "24×7", label: "Security & Power Backup" },
];

export default function About() {
  return (
    <section id="about" className="relative bg-white py-24 sm:py-32">
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-16 px-6 lg:grid-cols-12 lg:px-10">
        <div className="lg:col-span-6">
          <SectionHeading
            eyebrow="About the Residence"
            title={`Considered living, at the heart of ${COMPANY.address.split(",")[1]?.trim() || "Pandaveswar"}.`}
            description={`${COMPANY.project} is a premium residential community at ${COMPANY.address}, ${COMPANY.highway.toLowerCase()}. Designed for modern families, the project brings together premium apartments, landscaped open spaces and contemporary amenities — with excellent connectivity to hospitals, transit, schools, markets and everyday leisure.`}
          />

          <div className="mt-10 flex flex-wrap gap-3">
            {HIGHLIGHTS.slice(0, 8).map((h) => (
              <span
                key={h}
                className="rounded-full border border-emerald/15 bg-emerald/5 px-4 py-2 font-heading text-xs font-medium text-emerald"
              >
                {h}
              </span>
            ))}
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="grid grid-cols-2 gap-5 sm:gap-6">
            {STATS.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="card-lux rounded-2xl p-7"
              >
                <p className="font-display text-4xl font-bold text-emerald sm:text-5xl">{stat.value}</p>
                <p className="mt-2 font-heading text-sm text-dark/60">{stat.label}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-6 rounded-2xl bg-gradient-to-br from-emerald to-emerald-deep p-8 text-white"
          >
            <p className="font-display text-xl italic leading-relaxed text-white/90">
              &ldquo;A home should feel like a destination — every corridor, garden and
              skyline view considered on purpose.&rdquo;
            </p>
            <p className="mt-4 font-heading text-xs uppercase tracking-[0.2em] text-gold-light">
              — The Audamus Design Philosophy
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
