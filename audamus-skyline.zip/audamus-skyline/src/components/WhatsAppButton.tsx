"use client";

import { FaWhatsapp } from "react-icons/fa";
import { COMPANY } from "@/lib/data";

export default function WhatsAppButton() {
  const message = encodeURIComponent(
    `Hi, I'm interested in ${COMPANY.project}. Could you share more details?`
  );

  return (
    <a
      href={`https://wa.me/${COMPANY.phoneRaw}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      className="fixed bottom-6 left-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-xl shadow-black/20 transition-transform hover:scale-110"
    >
      <FaWhatsapp size={26} />
    </a>
  );
}
