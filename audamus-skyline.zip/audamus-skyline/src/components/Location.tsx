"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { HeartPulse, Bus, Trees } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { LOCATION_DATA, COMPANY } from "@/lib/data";

const TABS = [
  { id: "healthcare" as const, label: "Healthcare", icon: HeartPulse, angle: -90 },
  { id: "transport" as const, label: "Transport", icon: Bus, angle: 30 },
  { id: "leisure" as const, label: "Leisure", icon: Trees, angle: 150 },
];

export default function Location() {
  const [active, setActive] = useState<(typeof TABS)[number]["id"]>("healthcare");
  const entries = LOCATION_DATA[active];
  const mapQuery = encodeURIComponent(`${COMPANY.address}`);

  return (
    <section id="location" className="relative bg-emerald-deep py-24 text-white sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Location Advantage"
          title="Perfectly connected, right where you need it"
          description={`${COMPANY.address}, ${COMPANY.highway.toLowerCase()}.`}
          light
        />

        <div className="mt-14 grid grid-cols-1 gap-12 lg:grid-cols-12 lg:items-start">
          {/* Connectivity compass — signature diagram */}
          <div className="flex justify-center lg:col-span-5">
            <div className="relative h-[340px] w-[340px] sm:h-[400px] sm:w-[400px]">
              {[1, 2, 3].map((ring) => (
                <div
                  key={ring}
                  className="absolute rounded-full border border-white/10"
                  style={{
                    inset: `${(3 - ring) * 15}%`,
                  }}
                />
              ))}

              {/* Center marker */}
              <div className="absolute left-1/2 top-1/2 z-10 flex h-20 w-20 -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full bg-gold text-center shadow-xl shadow-gold/30">
                <span className="font-display text-[0.65rem] font-bold leading-tight text-dark">
                  Audamus
                  <br />
                  Skyline
                </span>
              </div>

              {TABS.map((tab) => {
                const rad = (tab.angle * Math.PI) / 180;
                const radius = 42;
                const x = 50 + radius * Math.cos(rad);
                const y = 50 + radius * Math.sin(rad);
                const isActive = active === tab.id;
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActive(tab.id)}
                    style={{ left: `${x}%`, top: `${y}%` }}
                    className="absolute -translate-x-1/2 -translate-y-1/2"
                  >
                    <motion.span
                      animate={{
                        scale: isActive ? 1.12 : 1,
                        backgroundColor: isActive ? "#D4AF37" : "rgba(255,255,255,0.08)",
                      }}
                      className="flex h-16 w-16 flex-col items-center justify-center gap-1 rounded-full border border-white/15 sm:h-20 sm:w-20"
                    >
                      <Icon size={20} className={isActive ? "text-dark" : "text-white/80"} />
                      <span
                        className={`font-heading text-[0.6rem] font-medium ${
                          isActive ? "text-dark" : "text-white/70"
                        }`}
                      >
                        {tab.label}
                      </span>
                    </motion.span>
                  </button>
                );
              })}

              {/* connecting lines */}
              <svg className="absolute inset-0 h-full w-full -z-0" viewBox="0 0 100 100">
                {TABS.map((tab) => {
                  const rad = (tab.angle * Math.PI) / 180;
                  const radius = 42;
                  const x = 50 + radius * Math.cos(rad);
                  const y = 50 + radius * Math.sin(rad);
                  return (
                    <line
                      key={tab.id}
                      x1="50"
                      y1="50"
                      x2={x}
                      y2={y}
                      stroke={active === tab.id ? "#D4AF37" : "rgba(255,255,255,0.15)"}
                      strokeWidth="0.5"
                    />
                  );
                })}
              </svg>
            </div>
          </div>

          {/* Distance list */}
          <div className="lg:col-span-7">
            <div className="overflow-hidden rounded-2xl border border-white/10">
              {entries.map((entry, i) => (
                <motion.div
                  key={entry.name}
                  initial={{ opacity: 0, x: 16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.4 }}
                  transition={{ duration: 0.45, delay: i * 0.06 }}
                  className="flex items-center justify-between gap-4 border-b border-white/8 bg-white/[0.03] px-6 py-4 last:border-none"
                >
                  <div>
                    <p className="font-heading text-sm font-medium text-white">{entry.name}</p>
                    {entry.note && <p className="mt-0.5 font-body text-xs text-white/50">{entry.note}</p>}
                  </div>
                  <div className="flex items-center gap-3">
                    {entry.hours && (
                      <span className="rounded-full bg-gold/15 px-2.5 py-1 font-heading text-[0.65rem] font-semibold text-gold-light">
                        {entry.hours}
                      </span>
                    )}
                    <span className="font-display text-base font-semibold text-gold-light">
                      {entry.distance}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Embedded map */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.7 }}
          className="mt-16 overflow-hidden rounded-3xl border border-white/10"
        >
          <iframe
            title="Audamus Skyline location map"
            src={`https://www.google.com/maps?q=${mapQuery}&output=embed`}
            width="100%"
            height="420"
            loading="lazy"
            className="grayscale-[15%]"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </motion.div>
      </div>
    </section>
  );
}
