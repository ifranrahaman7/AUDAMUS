"use client";

import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";
import { CONSTRUCTION_PHASES } from "@/lib/data";

export default function ConstructionUpdate() {
  return (
    <section id="construction" className="relative bg-grey py-24 sm:py-32">
      <div className="mx-auto max-w-4xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Progress You Can Track"
          title="Construction updates"
          description="A transparent look at where Audamus Skyline stands today."
          align="center"
        />

        <div className="mt-14 space-y-8">
          {CONSTRUCTION_PHASES.map((phase, i) => (
            <motion.div
              key={phase.phase}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
            >
              <div className="mb-2 flex items-baseline justify-between">
                <span className="font-heading text-sm font-semibold text-dark">{phase.phase}</span>
                <span className="font-heading text-sm text-emerald">
                  {phase.note ?? `${phase.progress}%`}
                </span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded-full bg-white">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${phase.progress}%` }}
                  viewport={{ once: true, amount: 0.5 }}
                  transition={{ duration: 1.1, delay: i * 0.1, ease: "easeOut" }}
                  className="h-full rounded-full bg-gradient-to-r from-emerald to-gold"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
