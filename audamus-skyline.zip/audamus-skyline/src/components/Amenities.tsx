"use client";

import { motion } from "framer-motion";
import {
  Waves,
  Dumbbell,
  Flower2,
  Users,
  Baby,
  Gamepad2,
  Building2,
  Footprints,
  Trees,
  Armchair,
  ParkingCircle,
  BatteryCharging,
  ShieldCheck,
  Camera,
  CloudRain,
  type LucideIcon,
} from "lucide-react";
import SectionHeading from "./SectionHeading";
import { AMENITIES } from "@/lib/data";

const ICON_MAP: Record<string, LucideIcon> = {
  pool: Waves,
  gym: Dumbbell,
  yoga: Flower2,
  clubhouse: Building2,
  kids: Baby,
  games: Gamepad2,
  hall: Users,
  track: Footprints,
  garden: Trees,
  senior: Armchair,
  parking: ParkingCircle,
  power: BatteryCharging,
  security: ShieldCheck,
  cctv: Camera,
  rain: CloudRain,
};

export default function Amenities() {
  return (
    <section id="amenities" className="relative bg-grey py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Resort-Style Living"
          title="Amenities designed around your day"
          description="From an early swim to a quiet evening walk, every amenity at Audamus Skyline is placed with everyday rhythm in mind."
        />

        <div className="mt-14 grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-5 lg:grid-cols-5">
          {AMENITIES.map((a, i) => {
            const Icon = ICON_MAP[a.icon] ?? ShieldCheck;
            return (
              <motion.div
                key={a.name}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.5, delay: (i % 10) * 0.05 }}
                whileHover={{ y: -6 }}
                className="card-lux group flex flex-col items-start gap-4 rounded-2xl p-6 transition-shadow hover:shadow-xl"
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald/8 text-emerald transition-colors group-hover:bg-emerald group-hover:text-white">
                  <Icon size={22} strokeWidth={1.75} />
                </span>
                <div>
                  <p className="font-heading text-sm font-semibold text-dark">{a.name}</p>
                  <p className="mt-1.5 font-body text-xs leading-relaxed text-dark/55">{a.blurb}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
