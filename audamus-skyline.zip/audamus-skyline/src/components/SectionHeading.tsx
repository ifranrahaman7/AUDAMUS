"use client";

import { motion } from "framer-motion";

type Props = {
  eyebrow: string;
  title: string;
  description?: string;
  light?: boolean;
  align?: "left" | "center";
};

export default function SectionHeading({ eyebrow, title, description, light, align = "left" }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.4 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className={align === "center" ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}
    >
      <p className="section-eyebrow mb-4">{eyebrow}</p>
      <h2
        className={`font-display text-3xl font-semibold leading-tight sm:text-4xl lg:text-[2.75rem] ${
          light ? "text-white" : "text-dark"
        }`}
      >
        {title}
      </h2>
      {description && (
        <p className={`mt-5 font-body text-[0.98rem] leading-relaxed ${light ? "text-white/70" : "text-dark/65"}`}>
          {description}
        </p>
      )}
    </motion.div>
  );
}
