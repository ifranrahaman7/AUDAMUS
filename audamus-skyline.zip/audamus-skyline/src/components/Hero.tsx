"use client";

import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { ChevronDown, Download } from "lucide-react";
import SkylineMotif from "./SkylineMotif";
import { COMPANY } from "@/lib/data";

export default function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "35%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.15]);

  return (
    <section
      id="home"
      ref={ref}
      className="relative flex h-[100svh] min-h-[640px] w-full items-end overflow-hidden bg-emerald-deep"
    >
      {/* Animated gradient backdrop standing in for a hero render */}
      <motion.div style={{ y, scale }} className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_#16493c_0%,_#0a2a22_55%,_#070f0d_100%)]" />
        <div className="absolute inset-0 opacity-[0.35] mix-blend-soft-light [background-image:radial-gradient(circle_at_20%_30%,#d4af37_0,transparent_35%),radial-gradient(circle_at_80%_75%,#0f5d4b_0,transparent_45%)]" />
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 1.6 }}
          className="absolute bottom-0 left-0 right-0 text-emerald-mid/70"
        >
          <SkylineMotif className="h-40 w-full sm:h-56" stroke="#0a2a22" />
        </motion.div>
      </motion.div>

      <motion.div style={{ opacity }} className="relative z-10 w-full">
        <div className="mx-auto max-w-7xl px-6 pb-20 pt-40 sm:pb-28 lg:px-10">
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="section-eyebrow mb-5"
          >
            Area More · Fulbagan · Pandaveswar
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.35 }}
            className="font-display max-w-4xl text-5xl font-semibold leading-[1.05] text-white sm:text-6xl lg:text-7xl"
          >
            {COMPANY.project}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.5 }}
            className="mt-6 max-w-xl font-heading text-lg font-light text-white/85 sm:text-xl"
          >
            {COMPANY.tagline}
          </motion.p>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.6 }}
            className="mt-2 max-w-xl font-body text-sm text-white/60"
          >
            {COMPANY.highway} · West Bengal
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.75 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <a href="#contact" className="btn-gold rounded-full px-7 py-3.5 text-sm">
              Book Site Visit
            </a>
            <a
              href="#floor-plans"
              className="btn-outline-light flex items-center gap-2 rounded-full px-7 py-3.5 text-sm"
            >
              <Download size={16} /> Download Brochure
            </a>
          </motion.div>
        </div>
      </motion.div>

      <motion.a
        href="#about"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 8, 0] }}
        transition={{ opacity: { delay: 1.2, duration: 1 }, y: { repeat: Infinity, duration: 1.8 } }}
        className="absolute bottom-6 left-1/2 z-10 -translate-x-1/2 text-white/70"
        aria-label="Scroll to next section"
      >
        <ChevronDown size={28} />
      </motion.a>
    </section>
  );
}
