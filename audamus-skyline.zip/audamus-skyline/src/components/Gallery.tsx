"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ImageIcon, ChevronLeft, ChevronRight } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { GALLERY_ITEMS } from "@/lib/data";

export default function Gallery() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const close = () => setActiveIndex(null);
  const next = () => setActiveIndex((i) => (i === null ? null : (i + 1) % GALLERY_ITEMS.length));
  const prev = () =>
    setActiveIndex((i) => (i === null ? null : (i - 1 + GALLERY_ITEMS.length) % GALLERY_ITEMS.length));

  return (
    <section id="gallery" className="relative bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="A Closer Look"
          title="Gallery"
          description="Visual placeholders shown below — final photography and renders will replace these ahead of launch."
          align="center"
        />

        <div className="mt-14 grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-5 lg:grid-cols-5">
          {GALLERY_ITEMS.map((item, i) => (
            <motion.button
              key={item.label}
              onClick={() => setActiveIndex(i)}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.5, delay: (i % 10) * 0.04 }}
              whileHover={{ scale: 1.03 }}
              className={`group relative aspect-[4/5] overflow-hidden rounded-xl bg-gradient-to-br ${item.tone} ${
                i === 0 ? "col-span-2 row-span-2 aspect-square sm:aspect-[4/5]" : ""
              }`}
            >
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 opacity-70 transition-opacity group-hover:opacity-100">
                <ImageIcon size={22} className="text-white/70" />
                <span className="px-3 text-center font-heading text-xs font-medium text-white/90">
                  {item.label}
                </span>
              </div>
              <div className="absolute inset-0 bg-black/0 transition-colors group-hover:bg-black/10" />
            </motion.button>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {activeIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-6"
            onClick={close}
          >
            <button className="absolute right-6 top-6 text-white/80 hover:text-white" onClick={close} aria-label="Close">
              <X size={28} />
            </button>
            <button
              className="absolute left-4 text-white/70 hover:text-white sm:left-8"
              onClick={(e) => {
                e.stopPropagation();
                prev();
              }}
              aria-label="Previous image"
            >
              <ChevronLeft size={32} />
            </button>
            <motion.div
              initial={{ scale: 0.92, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              onClick={(e) => e.stopPropagation()}
              className={`flex aspect-[4/5] w-full max-w-md flex-col items-center justify-center gap-3 rounded-2xl bg-gradient-to-br ${GALLERY_ITEMS[activeIndex].tone}`}
            >
              <ImageIcon size={36} className="text-white/70" />
              <p className="font-heading text-base font-medium text-white">{GALLERY_ITEMS[activeIndex].label}</p>
            </motion.div>
            <button
              className="absolute right-4 text-white/70 hover:text-white sm:right-8"
              onClick={(e) => {
                e.stopPropagation();
                next();
              }}
              aria-label="Next image"
            >
              <ChevronRight size={32} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
