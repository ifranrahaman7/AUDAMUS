"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, CheckCircle2 } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { COMPANY } from "@/lib/data";

const schema = z.object({
  name: z.string().min(2, "Please enter your full name"),
  phone: z
    .string()
    .min(10, "Enter a valid phone number")
    .regex(/^[0-9+\s-]+$/, "Digits only, please"),
  email: z.string().email("Enter a valid email address"),
  message: z.string().min(5, "Tell us a little about what you're looking for"),
});

type FormData = z.infer<typeof schema>;

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async () => {
    // No backend wired up yet — replace with your API route or CRM webhook.
    await new Promise((r) => setTimeout(r, 700));
    setSubmitted(true);
    reset();
  };

  return (
    <section id="contact" className="relative bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Get in Touch"
          title="Plan your visit to Audamus Skyline"
          description="Share your details and our sales team will help you plan a site visit at a time that suits you."
        />

        <div className="mt-14 grid grid-cols-1 gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="space-y-5">
              <a
                href={`tel:${COMPANY.phoneRaw}`}
                className="flex items-center gap-4 rounded-2xl bg-grey px-6 py-5 transition-colors hover:bg-emerald/5"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald/10 text-emerald">
                  <Phone size={19} />
                </span>
                <div>
                  <p className="font-heading text-xs uppercase tracking-wide text-dark/50">Call us</p>
                  <p className="font-heading text-sm font-semibold text-dark">{COMPANY.phone}</p>
                </div>
              </a>

              <a
                href={`mailto:${COMPANY.email}`}
                className="flex items-center gap-4 rounded-2xl bg-grey px-6 py-5 transition-colors hover:bg-emerald/5"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald/10 text-emerald">
                  <Mail size={19} />
                </span>
                <div>
                  <p className="font-heading text-xs uppercase tracking-wide text-dark/50">Email us</p>
                  <p className="font-heading text-sm font-semibold text-dark">{COMPANY.email}</p>
                </div>
              </a>

              <div className="flex items-center gap-4 rounded-2xl bg-grey px-6 py-5">
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-emerald/10 text-emerald">
                  <MapPin size={19} />
                </span>
                <div>
                  <p className="font-heading text-xs uppercase tracking-wide text-dark/50">Visit us</p>
                  <p className="font-heading text-sm font-semibold text-dark">{COMPANY.address}</p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            {submitted ? (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex h-full flex-col items-center justify-center rounded-3xl bg-emerald/5 p-12 text-center"
              >
                <CheckCircle2 size={40} className="text-emerald" />
                <p className="mt-4 font-display text-2xl font-semibold text-dark">Thank you</p>
                <p className="mt-2 max-w-sm font-body text-sm text-dark/60">
                  We&apos;ve received your details. Our team will reach out shortly to schedule your site visit.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-6 font-heading text-sm font-semibold text-emerald underline underline-offset-4"
                >
                  Send another enquiry
                </button>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit(onSubmit)} className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div className="sm:col-span-1">
                  <label className="mb-1.5 block font-heading text-xs font-medium text-dark/60">Full Name</label>
                  <input
                    {...register("name")}
                    placeholder="Your name"
                    className="w-full rounded-xl border border-dark/12 bg-white px-4 py-3 font-body text-sm outline-none transition-colors focus:border-emerald"
                  />
                  {errors.name && <p className="mt-1 text-xs text-red-500">{errors.name.message}</p>}
                </div>

                <div className="sm:col-span-1">
                  <label className="mb-1.5 block font-heading text-xs font-medium text-dark/60">Phone Number</label>
                  <input
                    {...register("phone")}
                    placeholder="+91 00000 00000"
                    className="w-full rounded-xl border border-dark/12 bg-white px-4 py-3 font-body text-sm outline-none transition-colors focus:border-emerald"
                  />
                  {errors.phone && <p className="mt-1 text-xs text-red-500">{errors.phone.message}</p>}
                </div>

                <div className="sm:col-span-2">
                  <label className="mb-1.5 block font-heading text-xs font-medium text-dark/60">Email Address</label>
                  <input
                    {...register("email")}
                    placeholder="you@example.com"
                    className="w-full rounded-xl border border-dark/12 bg-white px-4 py-3 font-body text-sm outline-none transition-colors focus:border-emerald"
                  />
                  {errors.email && <p className="mt-1 text-xs text-red-500">{errors.email.message}</p>}
                </div>

                <div className="sm:col-span-2">
                  <label className="mb-1.5 block font-heading text-xs font-medium text-dark/60">Message</label>
                  <textarea
                    {...register("message")}
                    rows={4}
                    placeholder="I'm interested in a 2 BHK at Audamus Skyline..."
                    className="w-full resize-none rounded-xl border border-dark/12 bg-white px-4 py-3 font-body text-sm outline-none transition-colors focus:border-emerald"
                  />
                  {errors.message && <p className="mt-1 text-xs text-red-500">{errors.message.message}</p>}
                </div>

                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="btn-gold w-full rounded-full px-6 py-3.5 text-sm disabled:opacity-60 sm:w-auto"
                  >
                    {isSubmitting ? "Sending..." : "Request a Site Visit"}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
