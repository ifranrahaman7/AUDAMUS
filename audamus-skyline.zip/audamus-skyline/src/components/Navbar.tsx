"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Download } from "lucide-react";
import { NAV_LINKS, COMPANY } from "@/lib/data";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "glass-nav py-3" : "bg-transparent py-6"
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 lg:px-10">
        <a href="#home" className="flex items-baseline gap-2">
          <span
            className={`font-display text-2xl font-bold tracking-wide transition-colors ${
              scrolled ? "text-emerald" : "text-white"
            }`}
          >
            Audamus
          </span>
          <span
            className={`font-heading text-[0.65rem] uppercase tracking-[0.3em] transition-colors ${
              scrolled ? "text-gold" : "text-gold-light"
            }`}
          >
            Skyline
          </span>
        </a>

        <ul className="hidden items-center gap-7 lg:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className={`font-heading text-[0.82rem] font-medium tracking-wide transition-colors hover:text-gold ${
                  scrolled ? "text-dark/80" : "text-white/90"
                }`}
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-3 lg:flex">
          <a
            href="#floor-plans"
            className={`flex items-center gap-1.5 font-heading text-[0.82rem] font-medium transition-colors hover:text-gold ${
              scrolled ? "text-dark/80" : "text-white/90"
            }`}
          >
            <Download size={15} /> Brochure
          </a>
          <a href="#contact" className="btn-gold rounded-full px-5 py-2.5 text-sm">
            Book Site Visit
          </a>
        </div>

        <button
          aria-label="Toggle menu"
          className={`lg:hidden ${scrolled ? "text-emerald" : "text-white"}`}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={26} /> : <Menu size={26} />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="glass-nav overflow-hidden lg:hidden"
          >
            <ul className="flex flex-col gap-1 px-6 py-4">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="block py-2.5 font-heading text-sm font-medium text-dark/85"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <a
                  href="#contact"
                  onClick={() => setOpen(false)}
                  className="btn-gold block rounded-full px-5 py-3 text-center text-sm"
                >
                  Book Site Visit
                </a>
              </li>
              <li className="pt-2 text-center font-heading text-xs text-dark/60">
                {COMPANY.phone}
              </li>
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
