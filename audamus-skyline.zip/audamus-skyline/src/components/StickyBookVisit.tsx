"use client";

import { Phone } from "lucide-react";
import { COMPANY } from "@/lib/data";

export default function StickyBookVisit() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 flex items-center gap-2 border-t border-dark/10 bg-white/95 p-3 backdrop-blur lg:hidden">
      <a
        href={`tel:${COMPANY.phoneRaw}`}
        className="flex flex-1 items-center justify-center gap-2 rounded-full border border-emerald/25 py-3 font-heading text-sm font-medium text-emerald"
      >
        <Phone size={16} /> Call
      </a>
      <a href="#contact" className="btn-gold flex-[1.4] rounded-full py-3 text-center text-sm">
        Book Site Visit
      </a>
    </div>
  );
}
