"use client";

import { useState } from "react";
import Link from "next/link";
import { ArrowUp } from "lucide-react";
import { FaFacebookF, FaInstagram, FaLinkedinIn, FaYoutube } from "react-icons/fa";
import SkylineMotif from "./SkylineMotif";
import { COMPANY, NAV_LINKS } from "@/lib/data";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setEmail("");
  };

  return (
    <footer className="relative bg-dark pt-20 text-white/70">
      <SkylineMotif className="h-10 w-full text-emerald/60 sm:h-14" />

      <div className="mx-auto max-w-7xl px-6 pb-10 pt-4 lg:px-10">
        <div className="grid grid-cols-1 gap-12 border-b border-white/10 pb-14 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <p className="font-display text-2xl font-bold text-white">
              Audamus <span className="text-gold">Skyline</span>
            </p>
            <p className="mt-4 max-w-xs font-body text-sm leading-relaxed text-white/55">
              A premium residential community at {COMPANY.address}, {COMPANY.highway.toLowerCase()}.
            </p>
            <div className="mt-6 flex gap-3">
              {[FaFacebookF, FaInstagram, FaLinkedinIn, FaYoutube].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="Social media link"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 transition-colors hover:border-gold hover:text-gold"
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <p className="font-heading text-sm font-semibold uppercase tracking-wide text-white">Quick Links</p>
            <ul className="mt-5 space-y-3">
              {NAV_LINKS.slice(0, 6).map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="font-body text-sm text-white/55 hover:text-gold-light">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-heading text-sm font-semibold uppercase tracking-wide text-white">Company</p>
            <ul className="mt-5 space-y-3">
              <li>
                <a href="#contact" className="font-body text-sm text-white/55 hover:text-gold-light">
                  Contact Us
                </a>
              </li>
              <li>
                <Link href="/privacy-policy" className="font-body text-sm text-white/55 hover:text-gold-light">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="font-body text-sm text-white/55 hover:text-gold-light">
                  Terms &amp; Conditions
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <p className="font-heading text-sm font-semibold uppercase tracking-wide text-white">Stay Updated</p>
            <p className="mt-5 font-body text-sm text-white/55">
              Get construction milestones and launch updates in your inbox.
            </p>
            {subscribed ? (
              <p className="mt-4 font-heading text-sm text-gold-light">You&apos;re subscribed — thank you.</p>
            ) : (
              <form onSubmit={handleSubscribe} className="mt-4 flex gap-2">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email"
                  className="w-full rounded-full border border-white/15 bg-white/5 px-4 py-2.5 font-body text-sm outline-none placeholder:text-white/40 focus:border-gold"
                />
                <button
                  type="submit"
                  className="shrink-0 rounded-full bg-gold px-4 py-2.5 font-heading text-xs font-semibold text-dark"
                >
                  Join
                </button>
              </form>
            )}
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 pt-8 sm:flex-row">
          <p className="font-body text-xs text-white/40">
            © {new Date().getFullYear()} {COMPANY.name}. All rights reserved.
          </p>
          <a
            href="#home"
            className="flex items-center gap-2 font-heading text-xs font-medium text-white/60 hover:text-gold"
          >
            Back to top <ArrowUp size={14} />
          </a>
        </div>
      </div>
    </footer>
  );
}
