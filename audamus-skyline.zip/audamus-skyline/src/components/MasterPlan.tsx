"use client";

import { motion } from "framer-motion";
import SectionHeading from "./SectionHeading";

const LEGEND = [
  { key: "A", label: "Entrance Gate", color: "#d4af37" },
  { key: "B", label: "Security Cabin", color: "#0f5d4b" },
  { key: "C", label: "Tower A" },
  { key: "D", label: "Tower B" },
  { key: "E", label: "Tower C" },
  { key: "F", label: "Clubhouse", color: "#0f5d4b" },
  { key: "G", label: "Swimming Pool", color: "#3aa5c9" },
  { key: "H", label: "Landscaped Garden", color: "#6fae55" },
  { key: "I", label: "Jogging Track", color: "#d4af37" },
  { key: "J", label: "Children's Park", color: "#e08a6b" },
  { key: "K", label: "Visitor Parking", color: "#8a8a8a" },
  { key: "L", label: "Open Green Space", color: "#6fae55" },
];

export default function MasterPlan() {
  return (
    <section id="master-plan" className="relative bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Site Layout"
          title="An original master plan, built for flow"
          description="Towers are set around a central green spine, keeping amenities, gardens and internal roads within easy reach of every block."
          align="center"
        />

        <div className="mt-14 grid grid-cols-1 gap-10 lg:grid-cols-12 lg:items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8 }}
            className="card-lux rounded-3xl p-4 sm:p-8 lg:col-span-8"
          >
            <svg viewBox="0 0 800 560" className="h-auto w-full" xmlns="http://www.w3.org/2000/svg">
              <rect x="0" y="0" width="800" height="560" rx="24" fill="#FBFAF7" />

              {/* Perimeter road */}
              <rect x="40" y="40" width="720" height="480" rx="18" fill="none" stroke="#D9D2C0" strokeWidth="26" />
              <rect x="40" y="40" width="720" height="480" rx="18" fill="none" stroke="#ffffff" strokeWidth="2" strokeDasharray="10 10" />

              {/* Entrance gate */}
              <rect x="360" y="12" width="80" height="30" rx="6" fill="#d4af37" />
              <text x="400" y="32" textAnchor="middle" fontSize="13" fontWeight="700" fill="#111">A</text>

              {/* Security cabin */}
              <rect x="368" y="58" width="64" height="26" rx="5" fill="#0f5d4b" />
              <text x="400" y="76" textAnchor="middle" fontSize="12" fontWeight="700" fill="#fff">B</text>

              {/* Towers */}
              {[
                { x: 110, y: 130, label: "C" },
                { x: 350, y: 110, label: "D" },
                { x: 590, y: 130, label: "E" },
              ].map((t) => (
                <g key={t.label}>
                  <rect x={t.x} y={t.y} width="120" height="160" rx="10" fill="#0F5D4B" opacity="0.92" />
                  <rect x={t.x + 14} y={t.y + 16} width="92" height="128" rx="4" fill="none" stroke="#E8C766" strokeWidth="1" strokeDasharray="3 6" />
                  <text x={t.x + 60} y={t.y + 88} textAnchor="middle" fontSize="16" fontWeight="700" fill="#fff">
                    {t.label}
                  </text>
                </g>
              ))}

              {/* Central green spine */}
              <ellipse cx="400" cy="330" rx="180" ry="70" fill="#6FAE55" opacity="0.25" />
              <text x="400" y="335" textAnchor="middle" fontSize="12" fontWeight="600" fill="#3f6b32">
                L · Open Green Space
              </text>

              {/* Clubhouse */}
              <rect x="330" y="380" width="140" height="60" rx="10" fill="#0F5D4B" />
              <text x="400" y="415" textAnchor="middle" fontSize="13" fontWeight="700" fill="#fff">F</text>

              {/* Pool */}
              <ellipse cx="230" cy="410" rx="55" ry="32" fill="#3AA5C9" opacity="0.85" />
              <text x="230" y="415" textAnchor="middle" fontSize="12" fontWeight="700" fill="#fff">G</text>

              {/* Garden */}
              <circle cx="590" cy="330" r="42" fill="#6FAE55" opacity="0.55" />
              <text x="590" y="335" textAnchor="middle" fontSize="12" fontWeight="700" fill="#2d4d24">H</text>

              {/* Jogging track (ring) */}
              <circle cx="400" cy="330" r="150" fill="none" stroke="#D4AF37" strokeWidth="4" strokeDasharray="14 10" opacity="0.8" />
              <text x="400" y="196" textAnchor="middle" fontSize="12" fontWeight="700" fill="#a3821f">I</text>

              {/* Children's park */}
              <rect x="600" y="400" width="90" height="60" rx="12" fill="#E08A6B" />
              <text x="645" y="435" textAnchor="middle" fontSize="12" fontWeight="700" fill="#fff">J</text>

              {/* Parking */}
              <rect x="90" y="440" width="120" height="46" rx="8" fill="#8A8A8A" opacity="0.85" />
              <text x="150" y="468" textAnchor="middle" fontSize="12" fontWeight="700" fill="#fff">K</text>
            </svg>
          </motion.div>

          <div className="lg:col-span-4">
            <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-1">
              {LEGEND.map((item) => (
                <li key={item.key} className="flex items-center gap-3 rounded-xl bg-grey/70 px-4 py-3">
                  <span
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-xs font-bold text-white"
                    style={{ background: item.color ?? "#0F5D4B" }}
                  >
                    {item.key}
                  </span>
                  <span className="font-heading text-sm text-dark/80">{item.label}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <p className="mt-6 text-center font-body text-xs text-dark/40">
          Illustrative master plan — indicative only, subject to statutory approvals and final layout.
        </p>
      </div>
    </section>
  );
}
