"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { SPECIFICATIONS } from "@/lib/data";

export default function Specifications() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="specifications" className="relative bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-5xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Built to Last"
          title="Specifications, in detail"
          description="Considered material choices across structure, finishes and safety systems."
          align="center"
        />

        <div className="mt-14 divide-y divide-dark/10 border-y border-dark/10">
          {SPECIFICATIONS.map((group, i) => {
            const isOpen = openIndex === i;
            return (
              <div key={group.title}>
                <button
                  onClick={() => setOpenIndex(isOpen ? null : i)}
                  className="flex w-full items-center justify-between py-5 text-left"
                >
                  <span className="font-heading text-base font-semibold text-dark sm:text-lg">
                    {group.title}
                  </span>
                  <motion.span
                    animate={{ rotate: isOpen ? 45 : 0 }}
                    transition={{ duration: 0.3 }}
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-emerald/8 text-emerald"
                  >
                    <Plus size={16} />
                  </motion.span>
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.35 }}
                      className="overflow-hidden"
                    >
                      <div className="grid grid-cols-1 gap-3 pb-6 sm:grid-cols-2">
                        {group.items.map((item) => (
                          <div key={item.label} className="rounded-xl bg-grey px-5 py-4">
                            <p className="font-heading text-xs uppercase tracking-wide text-gold">
                              {item.label}
                            </p>
                            <p className="mt-1 font-body text-sm text-dark/75">{item.value}</p>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
