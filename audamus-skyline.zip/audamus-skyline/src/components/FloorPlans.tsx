"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, Ruler } from "lucide-react";
import SectionHeading from "./SectionHeading";
import { FLOOR_PLANS } from "@/lib/data";

export default function FloorPlans() {
  const [active, setActive] = useState(FLOOR_PLANS[0].id);
  const plan = FLOOR_PLANS.find((p) => p.id === active)!;

  return (
    <section id="floor-plans" className="relative bg-grey py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <SectionHeading
          eyebrow="Homes to Choose From"
          title="Floor plans crafted for real living"
          description="Every layout is optimised for natural light, ventilation and practical room proportions."
        />

        <div className="mt-10 flex gap-3">
          {FLOOR_PLANS.map((p) => (
            <button
              key={p.id}
              onClick={() => setActive(p.id)}
              className={`rounded-full px-6 py-2.5 font-heading text-sm font-medium transition-all ${
                active === p.id
                  ? "bg-emerald text-white shadow-lg shadow-emerald/20"
                  : "bg-white text-dark/60 hover:text-emerald"
              }`}
            >
              {p.type}
            </button>
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.4 }}
            className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-12"
          >
            {/* Abstract floor plan diagram */}
            <div className="card-lux rounded-3xl p-6 sm:p-10 lg:col-span-7">
              <svg viewBox="0 0 500 380" className="h-auto w-full">
                <rect x="10" y="10" width="480" height="360" rx="10" fill="none" stroke="#0F5D4B" strokeWidth="2" />
                <line x1="10" y1="180" x2="320" y2="180" stroke="#0F5D4B" strokeWidth="1.5" />
                <line x1="320" y1="10" x2="320" y2="370" stroke="#0F5D4B" strokeWidth="1.5" />
                {plan.id === "3bhk" && <line x1="320" y1="180" x2="490" y2="180" stroke="#0F5D4B" strokeWidth="1.5" />}
                <line x1="150" y1="180" x2="150" y2="370" stroke="#0F5D4B" strokeWidth="1.5" />

                <text x="165" y="105" fontSize="13" fontWeight="600" fill="#0F5D4B" fontFamily="Poppins, sans-serif">
                  Living / Dining
                </text>
                <text x="45" y="275" fontSize="12" fontWeight="600" fill="#0F5D4B">
                  Master Bed
                </text>
                <text x="220" y="275" fontSize="12" fontWeight="600" fill="#0F5D4B">
                  Bedroom 2
                </text>
                <text x="360" y="105" fontSize="12" fontWeight="600" fill="#0F5D4B">
                  Kitchen
                </text>
                {plan.id === "3bhk" && (
                  <text x="360" y="275" fontSize="12" fontWeight="600" fill="#0F5D4B">
                    Bedroom 3
                  </text>
                )}
                <rect x="10" y="10" width="480" height="18" fill="#D4AF37" opacity="0.18" />
                <text x="250" y="24" textAnchor="middle" fontSize="11" fill="#a3821f" fontWeight="600">
                  Balcony
                </text>
              </svg>
              <p className="mt-4 text-center font-body text-xs text-dark/40">
                Indicative layout — not to scale.
              </p>
            </div>

            {/* Details */}
            <div className="lg:col-span-5">
              <p className="font-display text-3xl font-semibold text-dark">{plan.type} Residence</p>
              <p className="mt-2 flex items-center gap-2 font-heading text-sm text-emerald">
                <Ruler size={16} /> Carpet Area: {plan.area}
              </p>

              <div className="mt-6 divide-y divide-dark/8 rounded-2xl bg-white">
                {plan.dimensions.map((d) => (
                  <div key={d.room} className="flex items-center justify-between px-5 py-3.5">
                    <span className="font-body text-sm text-dark/70">{d.room}</span>
                    <span className="font-heading text-sm font-medium text-dark">{d.size}</span>
                  </div>
                ))}
              </div>

              <button className="btn-gold mt-6 flex items-center gap-2 rounded-full px-6 py-3 text-sm">
                <Download size={16} /> Download {plan.type} PDF
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </section>
  );
}
