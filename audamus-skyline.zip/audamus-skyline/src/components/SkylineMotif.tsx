type Props = {
  className?: string;
  stroke?: string;
};

/**
 * Original abstract skyline silhouette — the signature motif tying the
 * "Skyline" name to the visual language. Reused as a section divider,
 * in the hero background, and in the footer.
 */
export default function SkylineMotif({ className = "", stroke = "currentColor" }: Props) {
  return (
    <svg
      viewBox="0 0 1200 120"
      preserveAspectRatio="none"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 110 L60 110 L60 70 L90 70 L90 90 L120 90 L120 40 L150 40 L150 90 L180 90 L180 60 L210 60 L210 100 L250 100 L250 30 L270 30 L270 20 L290 20 L290 30 L310 30 L310 100 L360 100 L360 50 L390 50 L390 20 L410 20 L410 50 L440 50 L440 100 L500 100 L500 65 L520 65 L520 45 L540 45 L540 65 L560 65 L560 100 L620 100 L620 15 L640 15 L640 5 L660 5 L660 15 L680 15 L680 100 L740 100 L740 55 L760 55 L760 35 L780 35 L780 55 L800 55 L800 100 L860 100 L860 70 L890 70 L890 90 L920 90 L920 40 L950 40 L950 90 L980 90 L980 60 L1010 60 L1010 100 L1080 100 L1080 25 L1100 25 L1100 15 L1120 15 L1120 25 L1140 25 L1140 100 L1200 100 L1200 120 L0 120 Z"
        fill={stroke}
      />
    </svg>
  );
}
